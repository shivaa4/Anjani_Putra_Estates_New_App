package com.shivaprasad.anjaniputraestatesprivatelimited;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.google.android.material.button.MaterialButton;


public class VenturesFragment extends Fragment {

    Button el;
    MaterialButton button;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        // Must Fragment Initialization Compulsory
        View view = inflater.inflate(R.layout.fragment_ventures, container, false);

        // Icon City code end
        button = view.findViewById(R.id.il);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotoUrl("https://maps.app.goo.gl/iC8sE86HxcMz145G8");
            }

            private void gotoUrl(String s) {
                Uri uri = Uri.parse(s);
                startActivity(new Intent(Intent.ACTION_VIEW,uri));
            }
        });
        // Icon City code end


            // Enclave code start
            button = view.findViewById(R.id.el);
            button.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    gotoUrl("https://maps.app.goo.gl/87UaECM4BMdMGj236");
                }

                private void gotoUrl(String s) {
                    Uri uri = Uri.parse(s);
                    startActivity(new Intent(Intent.ACTION_VIEW,uri));
                }
            });
           // Enclave code end

                // Highway City code start
                button = view.findViewById(R.id.hl);
                button.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        gotoUrl("https://maps.app.goo.gl/drwkGt23trZHkaad6");
                    }

                    private void gotoUrl(String s) {
                        Uri uri = Uri.parse(s);
                        startActivity(new Intent(Intent.ACTION_VIEW,uri));
                    }
                });
                // Highway City code end

                    // NatureCity code start
                    button = view.findViewById(R.id.nl);
                    button.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            gotoUrl("https://maps.app.goo.gl/tPxgznotkyU2bBEH8");
                        }

                        private void gotoUrl(String s) {
                            Uri uri = Uri.parse(s);
                            startActivity(new Intent(Intent.ACTION_VIEW,uri));
                        }
                    });
                    // NatureCity code end

                        // Sandal City code start
                        button = view.findViewById(R.id.sl);
                        button.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                gotoUrl("https://maps.app.goo.gl/8Uwr2tZXSLmM6j4U6");
                            }

                            private void gotoUrl(String s) {
                                Uri uri = Uri.parse(s);
                                startActivity(new Intent(Intent.ACTION_VIEW,uri));
                            }
                        });
                        // Sandal City code end

                            // Diamond City code start
                            button = view.findViewById(R.id.dl);
                            button.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View view) {
                                    gotoUrl("https://maps.app.goo.gl/zEzT5tKvBamuzaxe9");
                                }

                                private void gotoUrl(String s) {
                                    Uri uri = Uri.parse(s);
                                    startActivity(new Intent(Intent.ACTION_VIEW,uri));
                                }
                            });
                            // Diamond City code end

                                // Platinum City code start
                                button = view.findViewById(R.id.pl);
                                button.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View view) {
                                        gotoUrl("https://maps.app.goo.gl/k4r2wzYjEK6eYA386");
                                    }

                                    private void gotoUrl(String s) {
                                        Uri uri = Uri.parse(s);
                                        startActivity(new Intent(Intent.ACTION_VIEW,uri));
                                    }
                                });
                                // Platinum City code end

                                    // Township City code start
                                    button = view.findViewById(R.id.tl);
                                    button.setOnClickListener(new View.OnClickListener() {
                                        @Override
                                        public void onClick(View view) {
                                            gotoUrl("https://maps.app.goo.gl/fsL6ZjDp2Hm4hZKS8");
                                        }

                                        private void gotoUrl(String s) {
                                            Uri uri = Uri.parse(s);
                                            startActivity(new Intent(Intent.ACTION_VIEW,uri));
                                        }
                                    });
                                    // Township City code end

                                        // Kohinoor City code start
                                        button = view.findViewById(R.id.kl);
                                        button.setOnClickListener(new View.OnClickListener() {
                                            @Override
                                            public void onClick(View view) {
                                                gotoUrl("https://maps.app.goo.gl/RQhdvUP18bCsGNzq5");
                                            }

                                            private void gotoUrl(String s) {
                                                Uri uri = Uri.parse(s);
                                                startActivity(new Intent(Intent.ACTION_VIEW,uri));
                                            }
                                        });
                                        // Kohinoor City code end


        // Inflate the layout for this fragment
        return view;
    }
}