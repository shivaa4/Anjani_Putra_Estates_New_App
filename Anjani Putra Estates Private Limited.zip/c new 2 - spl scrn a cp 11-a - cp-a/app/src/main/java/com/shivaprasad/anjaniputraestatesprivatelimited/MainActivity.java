package com.shivaprasad.anjaniputraestatesprivatelimited;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.IntentSender;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.ConnectivityManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.play.core.appupdate.AppUpdateInfo;
import com.google.android.play.core.appupdate.AppUpdateManager;
import com.google.android.play.core.appupdate.AppUpdateManagerFactory;
import com.google.android.play.core.install.InstallStateUpdatedListener;
import com.google.android.play.core.install.model.AppUpdateType;
import com.google.android.play.core.install.model.InstallStatus;
import com.google.android.play.core.install.model.UpdateAvailability;
import com.google.android.play.core.tasks.OnSuccessListener;
import com.google.android.play.core.tasks.Task;
import com.shivaprasad.anjaniputraestatesprivatelimited.Utility.NetworkChangeListener;

import java.time.Instant;

public class MainActivity extends AppCompatActivity {

    public static int UPADTE_CODE = 22;
    AppUpdateManager appUpdateManager;

    String[] permissions={"android.permission.POST_NOTIFICATIONS"};

    private AdView mAdView;

    Button lo;


    ImageView fb;
    ImageView instagram;
    ImageView youtube;
    ImageView twitter;
    ImageView telegram;

    ImageView lg;

    BottomNavigationView bottomNavigationView;

    HomeFragment homeFragment = new HomeFragment();
    VenturesFragment venturesFragment = new VenturesFragment();
    PolicyFragment policyFragment = new PolicyFragment();
    AboutusFragment aboutusFragment = new AboutusFragment();

    NetworkChangeListener networkChangeListener = new NetworkChangeListener();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        lg = findViewById(R.id.logo);
        final LoadingDialog loadingDialog = new LoadingDialog(MainActivity.this);

        inAppUp();

        if (Build.VERSION.SDK_INT>=Build.VERSION_CODES.M) {
            requestPermissions(permissions, 80);
        }


        fb = findViewById(R.id.fbimg);
        instagram = findViewById(R.id.instagramimg);
        youtube = findViewById(R.id.youtubeimg);
        twitter = findViewById(R.id.twitterimg);
        telegram = findViewById(R.id.telegramimg);
       // lg = findViewById(R.id.logo);





        fb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gotoUrl("https://www.facebook.com/anjaniputraestatesprivatelimited");
            }
        });

        instagram.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gotoUrl("https://www.instagram.com/anjaniputtraestates");
            }
        });

        youtube.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gotoUrl("https://youtube.com/@anjaniputraestates");
            }
        });

        twitter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gotoUrl("https://twitter.com/anjaniputtra");
            }
        });

        telegram.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gotoUrl("https://t.me/anjaniputraestatesprivatelimited");
            }
        });

        //testing code start

        lg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View sp) {
                loadingDialog.startLoadingDialog();
                Handler handler = new Handler();
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        loadingDialog.dismissDialog();
                        //Intent intent = new Intent (MainActivity.this, activity_seconedfgmnt.class);
                        //Intent intent = new Intent(MainActivity.this, second.class);

                       //lg.setOnClickListener(new View.OnClickListener() {
                        gotoUrl("https://anjaniputraestatesbrochers.blogspot.com/");

//                            @Override
//                            public void onClick(View v) {
//                                gotoUrl("https://anjaniputraestatesbrochers.blogspot.com/");
//                            }
                        //});
                        startActivity(sp);

                    }
                }, 5000);
            }
        });

        //testing code end

        //Brochers Website Opening Code Start
/*
        lg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gotoUrl("https://anjaniputraestatesbrochers.blogspot.com/");
            }
        });


 */
        //Brochers Website Opening Code End

       getSupportActionBar().setBackgroundDrawable(new ColorDrawable(getResources().getColor(R.color.clr)));

        bottomNavigationView = findViewById(R.id.bottom_navigation);

        getSupportFragmentManager().beginTransaction().replace(R.id.container, homeFragment).commit();

        bottomNavigationView.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected( MenuItem item) {

                switch (item.getItemId()){
                    case R.id.home:
                        getSupportFragmentManager().beginTransaction().replace(R.id.container,homeFragment).commit();
                        return true;

                    case R.id.ventures:
                        getSupportFragmentManager().beginTransaction().replace(R.id.container,venturesFragment).commit();
                        return true;

                    case R.id.about:
                        getSupportFragmentManager().beginTransaction().replace(R.id.container,aboutusFragment).commit();
                        return true;

                    case R.id.policy:
                        getSupportFragmentManager().beginTransaction().replace(R.id.container,policyFragment).commit();
                        return true;

                }

                return false;
            }
        });

       /* Hide Benner Ad

        mAdView = findViewById(R.id.adView);
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);

        */
    }

    private void startActivity(View v) {
    }

    // app update code starts
    private void inAppUp() {

        appUpdateManager = AppUpdateManagerFactory.create(this);
        Task<AppUpdateInfo> task = appUpdateManager.getAppUpdateInfo();
        task.addOnSuccessListener(new OnSuccessListener<AppUpdateInfo>() {
            @Override
            public void onSuccess(AppUpdateInfo appUpdateInfo) {

                if (appUpdateInfo.updateAvailability() == UpdateAvailability.UPDATE_AVAILABLE
                        && appUpdateInfo.isUpdateTypeAllowed(AppUpdateType.IMMEDIATE)
                ) {
                    try {
                        appUpdateManager.startUpdateFlowForResult(appUpdateInfo,AppUpdateType.IMMEDIATE,
                                MainActivity.this,
                                UPADTE_CODE
                        );
                    } catch (IntentSender.SendIntentException e) {
                        e.printStackTrace();

                        Log.d("updateerror", "onSuccess: "+e.toString());
                    }
                }

            }
        });

        appUpdateManager.registerListener(listener);

    }


    InstallStateUpdatedListener listener = installState -> {
        if (installState.installStatus() == InstallStatus.DOWNLOADED) {

            popUp();

        }
    };

    private void popUp() {

        Snackbar snackbar = Snackbar.make(
                findViewById(android.R.id.content),
                "App Update Almost Done.",
                Snackbar.LENGTH_INDEFINITE
        );

        snackbar.setAction("Reload", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                appUpdateManager.completeUpdate();
            }
        });

        snackbar.setTextColor(Color.parseColor("#FF5722"));
        snackbar.show();

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == UPADTE_CODE) {
            if (requestCode != RESULT_OK) {

            }
        }
    }

// app update code end

    //Notification permission code

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == 80) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                //  Toast.makeText(this, "Notifications On", Toast.LENGTH_LONG).show();
            }
            else {
                //Toast.makeText(this, "Notification Permission Required GoTo Settings", Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    protected void onStart() {
        IntentFilter filter = new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION);
        registerReceiver(networkChangeListener, filter);
        super.onStart();
    }

    @Override
    protected void onStop() {
        unregisterReceiver(networkChangeListener);
        super.onStop();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return super.onCreateOptionsMenu(menu);
    }


    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType("text/plain");
        intent.putExtra(Intent.EXTRA_SUBJECT, "GOVT ITI MANCHERIAL COLLEGE MOBILE APP AVAILABLE In Over College Website");
        intent.putExtra(Intent.EXTRA_TEXT, "Anjani Putra Estates Private Limited \n\n" +
                "Follow us on\n" +
                "Website : www.anjaniputraestates.com\n" +
                "Facebook : https://www.facebook.com/anjaniputraestatesprivatelimited\n" +
                "Instagram : https://www.instagram.com/anjaniputtraestates\n" +
                "Youtube : https://youtube.com/@anjaniputraestates\n" +
                "Twitter : https://twitter.com/anjaniputtra\n" +
                "Telegram : https://t.me/anjaniputraestatesprivatelimited\n");
        startActivity(Intent.createChooser(intent , "Share Via"));
        return super.onOptionsItemSelected(item);
    }
    

    private void gotoUrl(String s) {
        Uri uri = Uri.parse(s);
        startActivity(new Intent(Intent.ACTION_VIEW,uri));
    }

/*
Back Press Button Code Start
 */
    public void onBackPressed() {
        AlertDialog.Builder alertDialog = new AlertDialog.Builder(MainActivity.this);
        alertDialog.setTitle("Exit App");
        alertDialog.setMessage("Do you want to exit app ?");
        alertDialog.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                finishAffinity();
            }
        });
        alertDialog.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        alertDialog.show();
    }
/*
Back Press Button Code End

 */
}