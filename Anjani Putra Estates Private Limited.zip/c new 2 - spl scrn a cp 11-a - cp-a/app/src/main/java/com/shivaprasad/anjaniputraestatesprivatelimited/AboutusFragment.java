package com.shivaprasad.anjaniputraestatesprivatelimited;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.google.android.material.button.MaterialButton;


public class AboutusFragment extends Fragment {

    MaterialButton button;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        // Must Fragment Initialization Compulsory
        View view = inflater.inflate(R.layout.fragment_aboutus, container, false);

        // Icon City code end
        button = view.findViewById(R.id.ol);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotoUrl("https://maps.app.goo.gl/hmqLszdq3wBRqY4A8");
            }

            private void gotoUrl(String s) {
                Uri uri = Uri.parse(s);
                startActivity(new Intent(Intent.ACTION_VIEW,uri));
            }
        });
        // Icon City code end

        return view;
    }


}